import React from 'react'
import View from "react-native"

function EyesScanning() {
  return (
    <View>
      <Text>Eyes Scanning</Text>  
    </View>
  )
}

export default EyesScanning
